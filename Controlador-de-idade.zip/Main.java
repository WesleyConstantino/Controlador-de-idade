import java.util.Scanner;

class Main {
public static void main (String[] args) {

System.out.println("Digite sua idade");

Scanner age = new Scanner (System.in);

int idade = age.nextInt();

if (idade >= 18) {
  System.out.println("Você é maior de idade");
}

else if (idade < 18 && idade > 0) {
  System.out.println("Você é menor de idade");
}

else if (idade == 0) {
  System.out.println("Você é recém nascido");
}

else {
 System.out.println("Você ainda não nasceu");
    }
  }
}